@echo off
setlocal enabledelayedexpansion
set "INTERACTIVE=1"
if not "%~1"=="" set "INTERACTIVE=0"
if not "%~1"=="" goto :cli
if "%INTERACTIVE%"=="1" goto :menu

:menu
cls
echo ============================================
echo  API Endpoint Discovery - CONTROL AREA
echo ============================================
if not "%LASTURL%"=="" echo  Last URL: %LASTURL%
echo.
:askurl
set "URL="
set /p "URL=Target URL (e.g. https://example.com/): "
if "%URL%"=="" (
  if not "%LASTURL%"=="" (set "URL=%LASTURL%" & goto :urlok)
  echo  Please enter a URL. & goto :askurl
)
:urlok
echo %URL% | findstr /r /c:"^http://.." /c:"^https://.." >nul
if errorlevel 1 (echo  URL must start with http:// or https:// & goto :askurl)
set "LASTURL=%URL%"
echo.
echo  Modes:
echo   [1] Passive  - crawl + JS only (safe, quiet)
echo   [2] Active   - crawl + JS + brute-force (noisy)
echo   [3] Crawl only
echo   [4] JS only
echo   [5] Brute-force only
echo   [6] Custom (pick each)
echo.
set /p "CHOICE=Select mode [1-6, default 1]: "
if "%CHOICE%"=="" set "CHOICE=1"
set "DO_CRAWL=0" & set "DO_JS=0" & set "DO_BRUTE=0"
if "%CHOICE%"=="1" (set "DO_CRAWL=1" & set "DO_JS=1")
if "%CHOICE%"=="2" (set "DO_CRAWL=1" & set "DO_JS=1" & set "DO_BRUTE=1")
if "%CHOICE%"=="3" (set "DO_CRAWL=1")
if "%CHOICE%"=="4" (set "DO_JS=1")
if "%CHOICE%"=="5" (set "DO_BRUTE=1")
if "%CHOICE%"=="6" (
  set /p "DO_CRAWL=Crawl? (1/0) [1]: " & if "!DO_CRAWL!"=="" set "DO_CRAWL=1"
  set /p "DO_JS=JS parse? (1/0) [1]: " & if "!DO_JS!"=="" set "DO_JS=1"
  set /p "DO_BRUTE=Brute-force? (1/0) [0]: " & if "!DO_BRUTE!"=="" set "DO_BRUTE=0"
)
echo.
set /p "VERBOSE=Verbose (show working)? (1/0) [0]: "
if "%VERBOSE%"=="" set "VERBOSE=0"
set /p "SUBDOMAINS=Include subdomains (www., accounts., ...)? (1/0) [0]: "
if "%SUBDOMAINS%"=="" set "SUBDOMAINS=0"
set /p "WORDLIST=Wordlist file (blank=default): "
set /p "MAXPAGES=Max pages [30]: "
if "%MAXPAGES%"=="" set "MAXPAGES=30"
set /p "MAXSCRIPTS=Max scripts [20]: "
if "%MAXSCRIPTS%"=="" set "MAXSCRIPTS=20"
set /p "OUT=Output file (blank=auto-name): "
goto :run

:cli
if /i "%~1"=="--help" goto :help
set "URL=" & set "MODE=all"
set "DO_CRAWL=" & set "DO_JS=" & set "DO_BRUTE="
set "WORDLIST=" & set "MAXPAGES=30" & set "MAXSCRIPTS=20" & set "OUT=" & set "VERBOSE=0" & set "SUBDOMAINS=0"
set "EXPLICIT=0"
:cparse
if "%~1"=="" goto :cresolve
if /i "%~1"=="--url" (set "URL=%~2" & shift & shift & goto :cparse)
if /i "%~1"=="--mode" (set "MODE=%~2" & shift & shift & goto :cparse)
if /i "%~1"=="--crawl" (set "DO_CRAWL=1" & set "EXPLICIT=1" & shift & goto :cparse)
if /i "%~1"=="--js" (set "DO_JS=1" & set "EXPLICIT=1" & shift & goto :cparse)
if /i "%~1"=="--bruteforce" (set "DO_BRUTE=1" & set "EXPLICIT=1" & shift & goto :cparse)
if /i "%~1"=="--verbose" (set "VERBOSE=1" & shift & goto :cparse)
if /i "%~1"=="--subdomains" (set "SUBDOMAINS=1" & shift & goto :cparse)
if /i "%~1"=="--quiet" (set "VERBOSE=0" & shift & goto :cparse)
if /i "%~1"=="--wordlist" (set "WORDLIST=%~2" & shift & shift & goto :cparse)
if /i "%~1"=="--max-pages" (set "MAXPAGES=%~2" & shift & shift & goto :cparse)
if /i "%~1"=="--max-scripts" (set "MAXSCRIPTS=%~2" & shift & shift & goto :cparse)
if /i "%~1"=="--out" (set "OUT=%~2" & shift & shift & goto :cparse)
echo Unknown: %~1 & exit /b 1
:cresolve
if "%URL%"=="" (echo ERROR: --url is required. See --help. & exit /b 2)
if "%EXPLICIT%"=="0" (
  if /i "%MODE%"=="passive" (set "DO_CRAWL=1" & set "DO_JS=1" & set "DO_BRUTE=0")
  if /i "%MODE%"=="active" (set "DO_CRAWL=1" & set "DO_JS=1" & set "DO_BRUTE=1")
  if /i "%MODE%"=="all" (set "DO_CRAWL=1" & set "DO_JS=1" & set "DO_BRUTE=1")
)
if "%DO_CRAWL%"=="" set "DO_CRAWL=0"
if "%DO_JS%"=="" set "DO_JS=0"
if "%DO_BRUTE%"=="" set "DO_BRUTE=0"
goto :run

:help
echo Usage: run.bat --url URL [--mode passive^|active^|all] [--crawl] [--js] [--bruteforce]
echo                [--verbose^|--quiet] [--subdomains] [--wordlist f] [--max-pages N] [--max-scripts N] [--out f]
echo   No args = interactive control area. --url is required with args.
exit /b 0

:run
echo.
echo URL=%URL% crawl=%DO_CRAWL% js=%DO_JS% brute=%DO_BRUTE% verbose=%VERBOSE% subdomains=%SUBDOMAINS% pages=%MAXPAGES% scripts=%MAXSCRIPTS% out=%OUT%
echo.
python -m pytest test_endpoint_schema.py test_endpoint_crawler.py -q
if errorlevel 1 (echo TESTS FAILED & pause & exit /b 1)
set "VFLAG="
if "%VERBOSE%"=="1" set "VFLAG=--verbose"
set "SFLAG="
if "%SUBDOMAINS%"=="1" set "SFLAG=--subdomains"
set "SAVED_OUT=%OUT%"
if "%WORDLIST%"=="" (
  if "%OUT%"=="" (python run_pipeline.py --url "%URL%" --crawl %DO_CRAWL% --js %DO_JS% --brute %DO_BRUTE% --max-pages %MAXPAGES% --max-scripts %MAXSCRIPTS% %VFLAG% %SFLAG%) else (python run_pipeline.py --url "%URL%" --crawl %DO_CRAWL% --js %DO_JS% --brute %DO_BRUTE% --max-pages %MAXPAGES% --max-scripts %MAXSCRIPTS% --out "%OUT%" %VFLAG% %SFLAG%)
) else (
  if "%OUT%"=="" (python run_pipeline.py --url "%URL%" --crawl %DO_CRAWL% --js %DO_JS% --brute %DO_BRUTE% --wordlist "%WORDLIST%" --max-pages %MAXPAGES% --max-scripts %MAXSCRIPTS% %VFLAG% %SFLAG%) else (python run_pipeline.py --url "%URL%" --crawl %DO_CRAWL% --js %DO_JS% --brute %DO_BRUTE% --wordlist "%WORDLIST%" --max-pages %MAXPAGES% --max-scripts %MAXSCRIPTS% --out "%OUT%" %VFLAG% %SFLAG%)
)
if errorlevel 1 (echo PIPELINE FAILED & pause & exit /b 1)
if not "%SAVED_OUT%"=="" goto :skipauto
for /f "delims=" %%F in ('dir /b /o-d endpoints_*.json 2^>nul') do (set "OUT=%%F" & goto :gotout)
:gotout
:skipauto
echo.
echo Result saved to: %OUT%
goto :result

:result
echo.
echo  [1] View result JSON in CLI
echo  [2] Test another site
echo  [3] Exit
set /p "RCHOICE=Choose [1-3, default 3]: "
if "%RCHOICE%"=="" set "RCHOICE=3"
if "%RCHOICE%"=="1" (
  echo ---- %OUT% ----
  type "%OUT%"
  echo ---- end ----
  pause
  goto :result
)
if "%RCHOICE%"=="2" goto :menu
pause
exit /b 0
