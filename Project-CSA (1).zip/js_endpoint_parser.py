"""
js_endpoint_parser.py
=====================
Stage 2 (static JS analysis) for the API Endpoint Discovery Tool.

Finds API endpoints that only exist inside JavaScript, which
crawl_for_endpoints() cannot see:
  1. Extract <script src=...> URLs from crawled HTML pages
  2. Fetch each JS bundle as text
  3. Regex out endpoint-like strings (fetch/axios/XHR calls,
     absolute paths, /api/... literals)
  4. Package them as Endpoint records (Source.JS_STATIC) so
     Stage 3 can merge them with crawl + brute-force results.

Requires endpoint_schema.py and crawler.py in the same folder.
Owner: Abhijith
"""

from __future__ import annotations

import re
from typing import Optional
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup

from crawler import extract_links, is_allowed
from endpoint_crawler import fetch_with_metadata, in_scope
from endpoint_schema import (
    Endpoint,
    EndpointRegistry,
    Evidence,
    HttpMethod,
    Source,
)

# ---------------------------------------------------------------------------
# 1. Script URL extraction
# ---------------------------------------------------------------------------

def extract_script_urls(html: str, page_url: str) -> list[str]:
    """Return absolute URLs of all external <script src=...> on a page."""
    soup = BeautifulSoup(html, "html.parser")
    urls: list[str] = []
    for tag in soup.find_all("script", src=True):
        urls.append(urljoin(page_url, tag.get("src")))
    return urls


# ---------------------------------------------------------------------------
# 2. Endpoint patterns inside JS
# ---------------------------------------------------------------------------

# fetch("/api/users"), axios.get('/v1/orders'), $.ajax({url: "/graphql"}),
# bare literals like "/api/v1/login" or `https://host/api THING`
_PATTERNS = [
    # fetch("...") / fetch('...') / fetch(`...`)
    re.compile(r"""fetch\s*\(\s*[`'"]([^`'"]+)[`'"]"""),
    # axios.get("..."), axios.post('...'), axios({url: "..."})
    re.compile(r"""axios(?:\.\w+)?\s*\(\s*[`'"]([^`'"]+)[`'"]"""),
    re.compile(r"""url\s*:\s*[`'"]([^`'"]+)[`'"]"""),
    # $.ajax, $.get, $.post, XMLHttpRequest.open("GET", "...")
    re.compile(r"""\.open\s*\(\s*[`'"]\w+[`'"]\s*,\s*[`'"]([^`'"]+)[`'"]"""),
    re.compile(r"""\$\.(?:get|post|ajax)\s*\(\s*[`'"]([^`'"]+)[`'"]"""),
    # any quoted string starting with /api/, /v1/, /v2/, /rest/, /graphql
    re.compile(r"""[`'"](/(?:api|v\d+|rest|graphql)[^`'"]*)[`'"]"""),
]

# Skip templated junk / non-paths
_SKIP_RE = re.compile(r"^(https?:)?//[^/]*$|^(data:|blob:|javascript:)")


def _clean_candidate(raw: str) -> Optional[str]:
    raw = raw.strip()
    # strip ${...} template placeholders -> {id}-style is handled later by normalize
    raw = re.sub(r"\$\{[^}]*\}", "1", raw)
    raw = raw.split("?")[0].split("#")[0]
    if not raw.startswith("/") and not raw.startswith("http"):
        return None
    if _SKIP_RE.match(raw):
        return None
    path = urlparse(raw).path if raw.startswith("http") else raw
    if len(path) < 2 or "." in path.split("/")[-1] and "/" not in path.split("/")[-1][-8:]:
        # likely a static file (e.g. /main.chunk.js, /logo.png) -- skip
        # keep it simple: skip if last segment has a file extension
        last = path.rsplit("/", 1)[-1]
        if "." in last and last.rsplit(".", 1)[-1].isalpha() and len(last.rsplit(".", 1)[-1]) <= 4:
            # but keep known API-ish extensions like .json endpoints? no -- skip all
            return None
    return path or None


def _guess_method(js_text: str, match_start: int) -> HttpMethod:
    window = js_text[max(0, match_start - 120):match_start].lower()
    for method in ("post", "put", "delete", "patch"):
        if method in window:
            return HttpMethod(method.upper())
    return HttpMethod.GET


def extract_endpoints_from_js(js_text: str, origin: str) -> list[Endpoint]:
    """Regex-scan one JS bundle and return Endpoint records."""
    seen: dict[str, Endpoint] = {}
    for pat in _PATTERNS:
        for m in pat.finditer(js_text):
            path = _clean_candidate(m.group(1))
            if not path:
                continue
            method = _guess_method(js_text, m.start())
            key = f"{method.value}:{path}"
            if key in seen:
                continue
            seen[key] = Endpoint(
                method=method,
                path=path,
                sources=[Source.JS_STATIC],
                discovery_methods=["js_fetch_call"],
                evidence=[Evidence(
                    origin=origin,
                    detail=f"matched {pat.pattern[:40]}... -> {m.group(1)[:80]}",
                )],
            )
    return list(seen.values())


# ---------------------------------------------------------------------------
# 3. Crawl pages -> scripts -> endpoints
# ---------------------------------------------------------------------------

def crawl_js_endpoints(
    start_url: str,
    max_pages: int = 100,
    max_scripts: int = 50,
    delay_seconds: float = 0.2,
    timeout: int = 5,
    include_subdomains: bool = False,
) -> EndpointRegistry:
    """BFS pages (reusing crawler.extract_links/is_allowed), fetch each
    page's <script src> bundles, parse them with extract_endpoints_from_js."""
    import time

    domain = urlparse(start_url).netloc
    visited: set[str] = set()
    queue = [start_url]
    registry = EndpointRegistry()
    scripts_fetched = 0

    while queue and len(visited) < max_pages:
        url = queue.pop(0)
        if url in visited:
            continue
        visited.add(url)
        try:
            result = fetch_with_metadata(url, timeout=timeout)
        except requests.RequestException:
            continue
        if not in_scope(result.final_url, domain, include_subdomains=include_subdomains):
            continue
        if result.text:
            for link in extract_links(result.text, result.final_url):
                if in_scope(link, domain, include_subdomains=include_subdomains) and link not in visited:
                    queue.append(link)
            if scripts_fetched < max_scripts:
                for script_url in extract_script_urls(result.text, result.final_url):
                    if scripts_fetched >= max_scripts:
                        break
                    if not in_scope(script_url, domain, include_subdomains=include_subdomains) and urlparse(script_url).netloc != "":
                        continue  # third-party CDN -- skip
                    try:
                        r = requests.get(script_url, timeout=timeout)
                        js = r.text if "javascript" in r.headers.get("Content-Type", "") or "text" in r.headers.get("Content-Type", "") or script_url.endswith(".js") else r.text
                    except requests.RequestException:
                        continue
                    scripts_fetched += 1
                    for ep in extract_endpoints_from_js(js, origin=script_url):
                        registry.add(ep)
        time.sleep(delay_seconds)

    return registry


if __name__ == "__main__":
    import sys
    target = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:3000"
    reg = crawl_js_endpoints(target)
    print(f"Found {len(reg)} JS-derived endpoints")
    reg.save_json("js_endpoints.json")
