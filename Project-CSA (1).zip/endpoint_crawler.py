"""
endpoint_crawler.py
=====================
Endpoint-aware layer on top of crawler.py (the team's basic Stage 1 crawler).

crawler.py already does the core job of Stage 1 -- "systematically navigate
the target application": it follows <a href> links breadth-first and stays
on the same domain. This module does NOT reimplement that. It imports
crawler.py's own extract_links() and is_allowed() directly and reuses them,
then adds the layer Stage 1 needs to hand off to Stage 2/3 of the pipeline:

    1. Captures full response metadata per request (status, headers,
       content-type, redirect chain) -- crawler.py's fetch_page() throws
       this away and only returns response.text.
    2. Classifies which visited URLs actually look like API endpoints
       vs. ordinary HTML pages (heuristic -- see LIMITATIONS below).
    3. Packages endpoint-looking URLs as Endpoint records using
       endpoint_schema.py, so Stage 3 can consume them directly.
    4. Adds basic safety crawler.py doesn't have: a request delay, a page
       cap, an exclude-pattern list for obviously destructive links
       (/logout, /delete), and a scope re-check on the POST-redirect URL
       (crawler.py only scope-checks the URL it queued, not where a
       redirect actually lands).

Requires crawler.py and endpoint_schema.py in the same folder.

Owner: Abhijith (task: "Define endpoint crawler logic")
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass
from typing import Optional
from urllib.parse import urlparse

import requests

from crawler import extract_links, is_allowed  # reuse Member 1's logic as-is
from endpoint_schema import Endpoint, EndpointRegistry, Evidence, HttpMethod, Source


# ---------------------------------------------------------------------------
# Response capture
# ---------------------------------------------------------------------------

@dataclass
class FetchResult:
    requested_url: str
    final_url: str                 # differs from requested_url if redirected
    status_code: int
    headers: dict
    content_type: str
    elapsed_ms: float
    redirect_chain: list[str]
    text: Optional[str]            # None for binary/non-text content


def fetch_with_metadata(url: str, timeout: int = 5) -> FetchResult:
    """Does the same GET request crawler.fetch_page() does, but keeps the
    metadata that request needs discarding."""
    response = requests.get(url, timeout=timeout)
    content_type = response.headers.get("Content-Type", "")
    is_text = content_type.startswith(
        ("text/", "application/json", "application/xml", "application/javascript")
    )
    return FetchResult(
        requested_url=url,
        final_url=response.url,
        status_code=response.status_code,
        headers=dict(response.headers),
        content_type=content_type,
        elapsed_ms=response.elapsed.total_seconds() * 1000,
        redirect_chain=[r.url for r in response.history],
        text=response.text if is_text else None,
    )


# ---------------------------------------------------------------------------
# Endpoint classification -- heuristic only, see LIMITATIONS
# ---------------------------------------------------------------------------

API_PATH_HINTS = ("/api/", "/v1/", "/v2/", "/v3/", "/graphql", "/rest/", "/service/")

STATIC_FILE_EXTS = (".png", ".jpg", ".jpeg", ".gif", ".svg", ".ico", ".css",
                    ".woff", ".woff2", ".ttf", ".eot", ".mp4", ".webm")


def looks_like_endpoint(url: str, content_type: str) -> bool:
    """A visited URL is treated as an API endpoint if its path hints at
    one, or its response wasn't HTML (JSON/XML responses are never plain
    pages). Static assets (images/fonts/css) are never endpoints, even
    if served as non-HTML."""
    path = urlparse(url).path.lower()
    if path.endswith(STATIC_FILE_EXTS):
        return False
    if path.endswith(".js") or path.endswith(".js/"):
        return False  # JS bundles are parsed by Stage 2, not counted as endpoints
    if any(hint in path for hint in API_PATH_HINTS):
        return True
    if re.search(r"/v\d+/", path):
        return True
    if content_type and not content_type.startswith("text/html"):
        return True
    return False


# ---------------------------------------------------------------------------
# Scope control -- extends crawler.is_allowed() (domain-only) with an
# optional path prefix and an exclude list.
# ---------------------------------------------------------------------------

def in_scope(
    url: str,
    domain: str,
    path_prefix: Optional[str] = None,
    exclude_patterns: tuple[str, ...] = (),
    include_subdomains: bool = False,
) -> bool:
    host = urlparse(url).netloc
    if include_subdomains:
        base = domain.lstrip("www.").lower() if domain.lower().startswith("www.") else domain.lower()
        h = host.lower()
        if h != domain.lower() and h != base and not h.endswith("." + base):
            return False
    elif not is_allowed(url, domain):
        return False
    path = urlparse(url).path
    if path_prefix and not path.startswith(path_prefix):
        return False
    if any(pattern in path for pattern in exclude_patterns):
        return False
    return True


# ---------------------------------------------------------------------------
# Endpoint-aware crawl
# ---------------------------------------------------------------------------

def crawl_for_endpoints(
    start_url: str,
    path_prefix: Optional[str] = None,
    exclude_patterns: tuple[str, ...] = ("/logout", "/delete", "/signout"),
    delay_seconds: float = 0.2,
    max_pages: int = 500,
    include_subdomains: bool = False,
) -> EndpointRegistry:
    """Same breadth-first traversal as crawler.crawl(), but:
      - records an Endpoint for every visited URL that looks like an API
        endpoint (using endpoint_schema.py)
      - re-checks scope on the final URL after redirects, not just the
        URL that was queued
      - paces requests and caps total pages
      - skips a small list of obviously destructive-looking paths by
        default (crawler.py currently follows every link with no
        exceptions)
    """
    domain = urlparse(start_url).netloc
    visited: set[str] = set()
    queue = [start_url]
    registry = EndpointRegistry()

    while queue and len(visited) < max_pages:
        url = queue.pop(0)
        if url in visited:
            continue
        visited.add(url)

        try:
            result = fetch_with_metadata(url)
        except requests.RequestException as e:
            print("Error:", url, e)
            continue

        if not in_scope(result.final_url, domain, path_prefix, exclude_patterns, include_subdomains):
            continue  # redirected out of scope -- don't extract or record it

        if looks_like_endpoint(result.final_url, result.content_type):
            ep = Endpoint(
                method=HttpMethod.GET,  # following <a href> only ever issues GET
                path=urlparse(result.final_url).path,
                full_url=result.final_url,
                sources=[Source.CRAWLER],
                discovery_methods=["html_link"],
                headers_observed=list(result.headers.keys()),
                status_codes_observed={str(result.status_code): 1},
                evidence=[Evidence(
                    origin=url,
                    detail=f"{result.status_code} {result.content_type}",
                )],
            )
            registry.add(ep)

        if result.text:
            for link in extract_links(result.text, result.final_url):
                if in_scope(link, domain, path_prefix, exclude_patterns, include_subdomains) and link not in visited:
                    queue.append(link)

        time.sleep(delay_seconds)

    return registry


# ---------------------------------------------------------------------------
# Directory / endpoint brute-forcing
#
# crawl_for_endpoints() can only find what something links to. This probes
# a wordlist of common API paths directly, so it can surface endpoints
# nothing on the site ever points at (e.g. an old /api/v1/admin route).
#
# Many apps return HTTP 200 with a generic "not found" page instead of a
# real 404 (a "soft 404"), which would make a naive status-code check
# think every guess succeeded. To guard against that, this first probes a
# path that almost certainly doesn't exist and uses its response as a
# baseline; a guessed path only counts as "real" if it differs meaningfully
# from that baseline.
# ---------------------------------------------------------------------------

DEFAULT_WORDLIST = [
    "/api", "/api/v1", "/api/v2",
    "/api/users", "/api/user", "/api/login", "/api/logout", "/api/auth",
    "/api/admin", "/api/config", "/api/health", "/api/status",
    "/api/docs", "/api/orders", "/api/products", "/api/search",
    "/swagger.json", "/swagger.yaml", "/openapi.json", "/openapi.yaml",
    "/graphql", "/admin", "/admin/login", "/debug", "/internal",
    "/v1/users", "/v1/status", "/v2/users", "/.env",
]


def load_wordlist(filepath: str) -> list[str]:
    """One path per line, e.g. from a SecLists-style wordlist file."""
    with open(filepath, "r", encoding="utf-8") as f:
        return [line.strip() for line in f if line.strip() and not line.startswith("#")]


def _get_baseline(root_url: str, timeout: int) -> FetchResult:
    import random
    import string

    probe = "/__probe_" + "".join(random.choices(string.ascii_lowercase, k=12)) + "__"
    return fetch_with_metadata(root_url.rstrip("/") + probe, timeout=timeout)


def _is_probably_real(result: FetchResult, baseline: FetchResult, length_tolerance: int = 50) -> bool:
    if result.status_code == 404:
        return False
    if result.status_code != baseline.status_code:
        return True
    if result.content_type != baseline.content_type:
        return True
    # same status + content-type as the known-fake baseline -- likely a
    # soft-404 template. Only count it as real if the body meaningfully
    # differs in size from that template.
    if result.text is not None and baseline.text is not None:
        return abs(len(result.text) - len(baseline.text)) > length_tolerance
    return False


def brute_force_paths(
    base_url: str,
    wordlist: Optional[list[str]] = None,
    delay_seconds: float = 0.15,
    timeout: int = 5,
) -> EndpointRegistry:
    """Probes each path in `wordlist` directly against the target and
    records the ones that look real (see soft-404 note above)."""
    wordlist = wordlist or DEFAULT_WORDLIST
    parsed = urlparse(base_url)
    root = f"{parsed.scheme}://{parsed.netloc}"

    baseline = _get_baseline(root, timeout)
    registry = EndpointRegistry()

    for path in wordlist:
        url = root + "/" + path.lstrip("/")
        try:
            result = fetch_with_metadata(url, timeout=timeout)
        except requests.RequestException as e:
            print("Error:", url, e)
            continue

        if _is_probably_real(result, baseline):
            ep = Endpoint(
                method=HttpMethod.GET,
                path=urlparse(result.final_url).path,
                full_url=result.final_url,
                sources=[Source.CRAWLER],
                discovery_methods=["directory_bruteforce"],
                headers_observed=list(result.headers.keys()),
                status_codes_observed={str(result.status_code): 1},
                evidence=[Evidence(
                    origin="brute-force wordlist",
                    detail=f"{result.status_code} {result.content_type} (baseline was {baseline.status_code})",
                )],
            )
            registry.add(ep)

        time.sleep(delay_seconds)

    return registry


def combine_registries(*registries: EndpointRegistry) -> EndpointRegistry:
    """Merge crawl_for_endpoints() and brute_force_paths() results (or any
    number of registries) into one, deduping/merging overlapping records."""
    combined = EndpointRegistry()
    for reg in registries:
        for ep in reg.all():
            combined.add(ep)
    return combined


if __name__ == "__main__":
    crawled = crawl_for_endpoints("http://localhost:8000")
    brute_forced = brute_force_paths("http://localhost:8000")
    registry = combine_registries(crawled, brute_forced)

    print(f"Crawl found {len(crawled)}, brute-force found {len(brute_forced)}, "
          f"{len(registry)} unique after merge")
    registry.save_json("crawled_endpoints.json")


# ---------------------------------------------------------------------------
# LIMITATIONS -- features that cannot be implemented with the current
# crawler as it stands (see chat message for the full explanation of why,
# and what it would take to add each one)
# ---------------------------------------------------------------------------
#   - Only ever discovers GET endpoints (it can only follow <a href> links)
#   - Cannot see endpoints that only exist inside JavaScript (fetch/Axios
#     calls, SPA client-side routing) -- that is Stage 2's job by design
#   - No directory/endpoint brute-forcing (e.g. trying /api/v1/admin even
#     though no link points to it)
#   - No JavaScript execution, so client-rendered pages appear empty
#   - No auth/session/cookie handling, so anything behind a login is
#     unreachable
#   - No <form action="..."> extraction, so POST-only endpoints reachable
#     only via forms are missed
