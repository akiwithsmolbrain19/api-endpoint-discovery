"""
test_endpoint_crawler.py
==========================
Run with:  pytest test_endpoint_crawler.py -v

No live server needed -- requests.get is mocked with a small fake site so
we can verify classification, scope control, and the endpoint-recording
logic in isolation.
"""

from unittest.mock import patch

import pytest

from endpoint_crawler import (
    _is_probably_real,
    brute_force_paths,
    combine_registries,
    crawl_for_endpoints,
    fetch_with_metadata,
    in_scope,
    looks_like_endpoint,
)


# ---------------------------------------------------------------------------
# looks_like_endpoint
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("url,content_type,expected", [
    ("http://site.com/api/v1/users", "application/json", True),
    ("http://site.com/api/v1/users", "text/html", True),   # path hint wins
    ("http://site.com/dashboard", "text/html", False),
    ("http://site.com/data.json", "application/json", True),
    ("http://site.com/graphql", "text/html", True),
])
def test_looks_like_endpoint(url, content_type, expected):
    assert looks_like_endpoint(url, content_type) is expected


# ---------------------------------------------------------------------------
# in_scope
# ---------------------------------------------------------------------------

def test_in_scope_rejects_other_domain():
    assert in_scope("http://evil.com/x", "site.com") is False


def test_in_scope_respects_path_prefix():
    assert in_scope("http://site.com/admin/x", "site.com", path_prefix="/api") is False
    assert in_scope("http://site.com/api/x", "site.com", path_prefix="/api") is True


def test_in_scope_respects_exclude_patterns():
    assert in_scope("http://site.com/logout", "site.com", exclude_patterns=("/logout",)) is False


# ---------------------------------------------------------------------------
# Fake site for full crawl test
# ---------------------------------------------------------------------------

class FakeResponse:
    def __init__(self, url, text, status_code=200, content_type="text/html", history=None):
        self.url = url
        self.text = text
        self.status_code = status_code
        self.headers = {"Content-Type": content_type}
        self.history = history or []
        self.elapsed = type("E", (), {"total_seconds": lambda self=None: 0.01})()


FAKE_SITE = {
    "http://site.com/": FakeResponse(
        "http://site.com/",
        '<a href="/dashboard">dash</a><a href="/api/v1/users">users api</a>'
        '<a href="/logout">logout</a>',
    ),
    "http://site.com/dashboard": FakeResponse(
        "http://site.com/dashboard",
        '<a href="/api/v1/orders">orders api</a>',
    ),
    "http://site.com/api/v1/users": FakeResponse(
        "http://site.com/api/v1/users", '{"users": []}', content_type="application/json",
    ),
    "http://site.com/api/v1/orders": FakeResponse(
        "http://site.com/api/v1/orders", '{"orders": []}', content_type="application/json",
    ),
    "http://site.com/logout": FakeResponse("http://site.com/logout", "<p>bye</p>"),
}


def fake_get(url, timeout=5):
    if url not in FAKE_SITE:
        raise AssertionError(f"crawler requested an unexpected URL: {url}")
    return FAKE_SITE[url]


def test_fetch_with_metadata_uses_get():
    with patch("endpoint_crawler.requests.get", side_effect=fake_get):
        result = fetch_with_metadata("http://site.com/api/v1/users")
    assert result.status_code == 200
    assert result.content_type == "application/json"
    assert result.text == '{"users": []}'


def test_crawl_for_endpoints_finds_only_api_urls_and_skips_logout():
    with patch("endpoint_crawler.requests.get", side_effect=fake_get):
        registry = crawl_for_endpoints("http://site.com/", delay_seconds=0)

    found_paths = {ep.path for ep in registry.all()}
    assert found_paths == {"/api/v1/users", "/api/v1/orders"}
    # /dashboard and / are real pages but not endpoints -> correctly excluded
    # /logout is excluded by the default exclude_patterns and never fetched --
    # confirmed by FAKE_SITE's fake_get() raising if an unexpected URL is requested


def test_crawl_for_endpoints_respects_max_pages():
    with patch("endpoint_crawler.requests.get", side_effect=fake_get):
        registry = crawl_for_endpoints("http://site.com/", delay_seconds=0, max_pages=1)
    # only the start page gets visited -> no endpoints reached yet
    assert len(registry) == 0


# ---------------------------------------------------------------------------
# Brute-forcing + soft-404 detection
# ---------------------------------------------------------------------------

SOFT_404_BODY = "<html><body>Nothing here!</body></html>"  # what the fake app returns for ANY unknown path

def brute_force_fake_get(url, timeout=5):
    # Simulates an app that returns HTTP 200 + a generic page for EVERY
    # unknown path (a soft-404) instead of a real 404 -- including for the
    # brute-forcer's random baseline probe. Only /api/admin and /api/users
    # are "real" and should be distinguishable from that generic page.
    if "/api/admin" in url:
        return FakeResponse(url, '{"admin": true, "settings": {}}', status_code=200, content_type="application/json")
    if "/api/users" in url:
        return FakeResponse(url, '{"users": [1, 2, 3]}', status_code=200, content_type="application/json")
    return FakeResponse(url, SOFT_404_BODY, status_code=200, content_type="text/html")


def test_is_probably_real_flags_different_content_type_as_real():
    from endpoint_crawler import FetchResult
    b = FetchResult("p", "p", 200, {}, "text/html", 1.0, [], SOFT_404_BODY)
    r = FetchResult("u", "u", 200, {}, "application/json", 1.0, [], '{"users": []}')
    assert _is_probably_real(r, b) is True


def test_is_probably_real_rejects_matching_soft_404():
    from endpoint_crawler import FetchResult
    b = FetchResult("p", "p", 200, {}, "text/html", 1.0, [], SOFT_404_BODY)
    same = FetchResult("u", "u", 200, {}, "text/html", 1.0, [], SOFT_404_BODY)
    assert _is_probably_real(same, b) is False


def test_brute_force_paths_finds_real_endpoints_and_skips_soft_404s():
    wordlist = ["/api/users", "/api/admin", "/api/config", "/api/nonexistent"]
    with patch("endpoint_crawler.requests.get", side_effect=brute_force_fake_get):
        registry = brute_force_paths("http://site.com", wordlist=wordlist, delay_seconds=0)

    found_paths = {ep.path for ep in registry.all()}
    assert found_paths == {"/api/users", "/api/admin"}
    for ep in registry.all():
        assert ep.discovery_methods == ["directory_bruteforce"]


def fake_get_with_probe_support(url, timeout=5):
    # brute_force_paths() always probes a random /__probe_xxx__ path first
    # to build its soft-404 baseline; the fixed FAKE_SITE map doesn't know
    # about it, so handle it here as a genuine 404.
    if "/__probe_" in url:
        return FakeResponse(url, "Not Found", status_code=404, content_type="text/plain")
    return fake_get(url, timeout)


def test_combine_registries_merges_same_endpoint_found_both_ways():
    # crawl (via fake_get) finds GET /api/v1/users through a link.
    with patch("endpoint_crawler.requests.get", side_effect=fake_get):
        crawled = crawl_for_endpoints("http://site.com/", delay_seconds=0)

    # brute-force independently guesses the same path with a fresh probe.
    with patch("endpoint_crawler.requests.get", side_effect=fake_get_with_probe_support):
        brute_forced = brute_force_paths(
            "http://site.com", wordlist=["/api/v1/users"], delay_seconds=0
        )

    combined = combine_registries(crawled, brute_forced)
    users_records = [ep for ep in combined.all() if ep.path == "/api/v1/users"]

    assert len(users_records) == 1  # deduped into a single record, not two
    assert set(users_records[0].discovery_methods) == {"html_link", "directory_bruteforce"}
