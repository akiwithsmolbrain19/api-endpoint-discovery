"""
endpoint_schema.py
===================
Canonical data structure + JSON (de)serialization for the API Endpoint
Discovery Tool.

This module is the shared "contract" between all four pipeline stages:

    Stage 1 (Crawler)        -> produces Endpoint records (source=CRAWLER)
    Stage 2 (JS Analysis)    -> produces Endpoint records (source=JS_STATIC)
    Stage 3 (Normalization)  -> merges/dedupes records, cross-checks against
                                 OpenAPI/Swagger (source=OPENAPI_SPEC),
                                 sets `documented`
    Stage 4 (Map/Report)     -> reads the final JSON database to render
                                 the interactive endpoint map

Design goals:
    - stdlib only (no extra installs needed by teammates)
    - every field has a clear owner/purpose tied back to a pipeline stage
    - safe to merge records about the SAME endpoint found by different
      stages/sources without losing provenance (who found it, how, when)

Owner: Abhijith (task: "Define endpoint data structure and JSON handling")
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import Optional, Union


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class Source(str, Enum):
    """Which stage/technique originally discovered this endpoint."""
    CRAWLER = "crawler"            # Stage 1: link following / brute force
    JS_STATIC = "js_static"        # Stage 2: parsed out of JS bundles
    OPENAPI_SPEC = "openapi_spec"  # Stage 3: found in official docs
    MANUAL = "manual"              # manually added / testing


class HttpMethod(str, Enum):
    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    PATCH = "PATCH"
    DELETE = "DELETE"
    OPTIONS = "OPTIONS"
    HEAD = "HEAD"
    UNKNOWN = "UNKNOWN"   # e.g. a path found in JS with no method context


# ---------------------------------------------------------------------------
# Supporting structures
# ---------------------------------------------------------------------------

@dataclass
class Parameter:
    """A single query/path/body/header parameter observed for an endpoint."""
    name: str
    location: str                    # "query" | "path" | "body" | "header"
    example: Optional[str] = None
    inferred_type: str = "string"    # "string" | "number" | "boolean" | "uuid" | "unknown"

    def to_dict(self) -> dict:
        return asdict(self)

    @staticmethod
    def from_dict(d: dict) -> "Parameter":
        return Parameter(**d)


@dataclass
class Evidence:
    """Where this endpoint was actually seen -- keeps the tool auditable so
    Stage 4's report can point back to proof instead of a bare claim."""
    origin: str                      # e.g. filename, JS bundle URL, or page URL
    detail: str = ""                 # e.g. "line 214: fetch(`/api/orders/${id}`)"
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_dict(self) -> dict:
        return asdict(self)

    @staticmethod
    def from_dict(d: dict) -> "Evidence":
        return Evidence(**d)


# ---------------------------------------------------------------------------
# Core record
# ---------------------------------------------------------------------------

@dataclass
class Endpoint:
    method: HttpMethod
    path: str                                  # raw path as first observed
    normalized_path: str = ""                  # templated path, e.g. /users/{id}
    full_url: Optional[str] = None

    sources: list[Source] = field(default_factory=list)
    discovery_methods: list[str] = field(default_factory=list)
    # e.g. "html_link", "directory_bruteforce", "js_fetch_call", "js_axios_call", "swagger_doc"

    parameters: list[Parameter] = field(default_factory=list)
    headers_observed: list[str] = field(default_factory=list)
    status_codes_observed: dict[str, int] = field(default_factory=dict)   # {"200": 3, "404": 1}

    documented: bool = False
    doc_operation_id: Optional[str] = None      # link back to OpenAPI operationId if matched

    security_score: Optional[float] = None      # filled in later by Member 4's scoring pass
    tags: list[str] = field(default_factory=list)   # e.g. "undocumented", "auth-required", "admin"

    evidence: list[Evidence] = field(default_factory=list)

    first_seen: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    last_seen: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    endpoint_id: str = ""    # composite dedup key, auto-generated if left blank

    def __post_init__(self):
        if isinstance(self.method, str):
            self.method = HttpMethod(self.method)
        if not self.normalized_path:
            self.normalized_path = normalize_path(self.path)
        if not self.endpoint_id:
            self.endpoint_id = generate_id(self.method, self.normalized_path)

    # -- serialization -------------------------------------------------
    def to_dict(self) -> dict:
        d = asdict(self)
        d["method"] = self.method.value
        d["sources"] = [s.value if isinstance(s, Source) else s for s in self.sources]
        return d

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent)

    @staticmethod
    def from_dict(d: dict) -> "Endpoint":
        d = dict(d)  # don't mutate caller's dict
        d["sources"] = [Source(s) for s in d.get("sources", [])]
        d["parameters"] = [Parameter.from_dict(p) for p in d.get("parameters", [])]
        d["evidence"] = [Evidence.from_dict(e) for e in d.get("evidence", [])]
        return Endpoint(**d)

    @staticmethod
    def from_json(s: str) -> "Endpoint":
        return Endpoint.from_dict(json.loads(s))


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_ID_SEGMENT = re.compile(
    r"^("
    r"\d+"                                                                       # numeric id
    r"|[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"  # UUID
    r"|[0-9a-fA-F]{24}"                                                           # Mongo ObjectId
    r")$"
)


def normalize_path(path: str) -> str:
    """Collapse variable path segments (ids/uuids) into {id} so that
    /api/users/17 and /api/users/42 dedupe to the same logical endpoint."""
    segments = [seg for seg in path.strip("/").split("/")]
    if segments == [""]:
        return "/"
    normalized = ["{id}" if _ID_SEGMENT.match(seg) else seg for seg in segments]
    return "/" + "/".join(normalized)


def generate_id(method: Union[HttpMethod, str], normalized_path: str) -> str:
    m = method.value if isinstance(method, HttpMethod) else method
    key = f"{m}:{normalized_path}".encode()
    return hashlib.sha256(key).hexdigest()[:12]


def merge_endpoints(a: Endpoint, b: Endpoint) -> Endpoint:
    """Combine two records about the SAME endpoint (same method +
    normalized_path) found via different stages/sources. Preserves full
    provenance instead of one overwriting the other."""
    if a.endpoint_id != b.endpoint_id:
        raise ValueError(
            f"Refusing to merge different endpoints: {a.endpoint_id} != {b.endpoint_id}"
        )

    return Endpoint(
        method=a.method,
        path=a.path,
        normalized_path=a.normalized_path,
        full_url=a.full_url or b.full_url,
        sources=list(dict.fromkeys(a.sources + b.sources)),
        discovery_methods=list(dict.fromkeys(a.discovery_methods + b.discovery_methods)),
        parameters=_merge_parameters(a.parameters, b.parameters),
        headers_observed=list(dict.fromkeys(a.headers_observed + b.headers_observed)),
        status_codes_observed=_merge_status_codes(a.status_codes_observed, b.status_codes_observed),
        documented=a.documented or b.documented,
        doc_operation_id=a.doc_operation_id or b.doc_operation_id,
        security_score=a.security_score if a.security_score is not None else b.security_score,
        tags=list(dict.fromkeys(a.tags + b.tags)),
        evidence=a.evidence + b.evidence,
        first_seen=min(a.first_seen, b.first_seen),
        last_seen=max(a.last_seen, b.last_seen),
        endpoint_id=a.endpoint_id,
    )


def _merge_parameters(a: list[Parameter], b: list[Parameter]) -> list[Parameter]:
    seen = {(p.name, p.location): p for p in a}
    for p in b:
        seen.setdefault((p.name, p.location), p)
    return list(seen.values())


def _merge_status_codes(a: dict[str, int], b: dict[str, int]) -> dict[str, int]:
    out = dict(a)
    for code, count in b.items():
        out[code] = out.get(code, 0) + count
    return out


# ---------------------------------------------------------------------------
# Registry: the running "database" of every endpoint found so far
# ---------------------------------------------------------------------------

class EndpointRegistry:
    """In-memory store + JSON load/save for the whole endpoint database.
    Stage 1 and Stage 2 scripts can each build their own registry and
    export it to JSON; Stage 3 loads both files and merges them via add()."""

    def __init__(self):
        self._by_id: dict[str, Endpoint] = {}

    def add(self, ep: Endpoint) -> Endpoint:
        existing = self._by_id.get(ep.endpoint_id)
        self._by_id[ep.endpoint_id] = merge_endpoints(existing, ep) if existing else ep
        return self._by_id[ep.endpoint_id]

    def all(self) -> list[Endpoint]:
        return list(self._by_id.values())

    def __len__(self) -> int:
        return len(self._by_id)

    def save_json(self, filepath: str) -> None:
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump([ep.to_dict() for ep in self.all()], f, indent=2)

    @staticmethod
    def load_json(filepath: str) -> "EndpointRegistry":
        reg = EndpointRegistry()
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
        for item in data:
            reg.add(Endpoint.from_dict(item))
        return reg


# ---------------------------------------------------------------------------
# Quick demo / sanity check -- run: python endpoint_schema.py
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    ep1 = Endpoint(
        method=HttpMethod.GET,
        path="/api/v1/users/17",
        full_url="https://target.example.com/api/v1/users/17",
        sources=[Source.CRAWLER],
        discovery_methods=["html_link"],
        status_codes_observed={"200": 1},
        evidence=[Evidence(origin="crawl: /dashboard", detail="found <a href> link")],
    )

    ep2 = Endpoint(
        method=HttpMethod.GET,
        path="/api/v1/users/42",   # different id, same shape -> same normalized_path
        sources=[Source.JS_STATIC],
        discovery_methods=["js_fetch_call"],
        parameters=[Parameter(name="include", location="query", example="profile")],
        evidence=[Evidence(
            origin="main.bundle.js",
            detail="line 214: fetch(`/api/v1/users/${id}?include=profile`)",
        )],
    )

    registry = EndpointRegistry()
    registry.add(ep1)
    registry.add(ep2)

    assert len(registry) == 1, "same method+shape should merge into one record"

    print(f"Registry has {len(registry)} unique endpoint(s) after merge:\n")
    for ep in registry.all():
        print(ep.to_json())

    registry.save_json("demo_endpoints.json")
    print("\nSaved to demo_endpoints.json")
