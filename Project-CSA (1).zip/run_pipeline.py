"""run_pipeline.py - backend for run.bat (argparse, flat folder)."""
import argparse, sys, re
from datetime import datetime
sys.path.insert(0, ".")
from endpoint_crawler import crawl_for_endpoints, brute_force_paths, load_wordlist
from endpoint_schema import EndpointRegistry
from js_endpoint_parser import crawl_js_endpoints

p = argparse.ArgumentParser(description="API Endpoint Discovery - pipeline runner")
p.add_argument("--url", required=True)
p.add_argument("--crawl", default="1")
p.add_argument("--js", default="1")
p.add_argument("--brute", default="0")
p.add_argument("--wordlist", default=None)
p.add_argument("--max-pages", type=int, default=30)
p.add_argument("--max-scripts", type=int, default=20)
p.add_argument("--out", default=None)
p.add_argument("--verbose", action="store_true", help="show per-page/per-probe working")
p.add_argument("--subdomains", action="store_true", help="follow subdomains (www., accounts., etc.)")
a = p.parse_args()
on = lambda v: str(v).lower() in ("1", "true", "yes", "on")
verbose = a.verbose

if not a.url.startswith(("http://", "https://")):
    print(f"ERROR: URL must start with http:// or https:// (got: {a.url})")
    sys.exit(2)

if not a.out:
    domain = re.sub(r"^https?://", "", a.url).split("/")[0].replace(":", "_")
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    a.out = f"endpoints_{domain}_{stamp}.json"

regs = []
if on(a.crawl):
    print("[crawl] visiting pages...")
    c = crawl_for_endpoints(a.url, max_pages=a.max_pages, include_subdomains=a.subdomains)
    if verbose:
        for ep in c.all():
            print(f"  [crawl-hit] {ep.method.value} {ep.path} via {ep.discovery_methods}")
    print(f"  crawl: {len(c)} endpoints")
    regs.append(c)
if on(a.js):
    print("[js] fetching scripts + scanning bundles...")
    j = crawl_js_endpoints(a.url, max_pages=min(a.max_pages, 20), max_scripts=a.max_scripts, include_subdomains=a.subdomains)
    if verbose:
        for ep in j.all():
            ev = ep.evidence[0].origin if ep.evidence else "?"
            print(f"  [js-hit] {ep.method.value} {ep.path} from {ev}")
    print(f"  js: {len(j)} endpoints")
    regs.append(j)
if on(a.brute):
    wl = load_wordlist(a.wordlist) if a.wordlist else None
    print(f"[brute] probing {len(wl) if wl else 'default'} paths...")
    b = brute_force_paths(a.url, wordlist=wl)
    if verbose:
        for ep in b.all():
            print(f"  [brute-hit] {ep.method.value} {ep.path}")
    print(f"  brute: {len(b)} endpoints")
    regs.append(b)

combined = EndpointRegistry()
for r in regs:
    for ep in r.all():
        combined.add(ep)
combined.save_json(a.out)
print(f"unique: {len(combined)} -> {a.out}")
for ep in combined.all():
    print(f"  {ep.method.value} {ep.path} {ep.discovery_methods}")
