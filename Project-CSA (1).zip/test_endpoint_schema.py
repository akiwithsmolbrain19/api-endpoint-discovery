"""
test_endpoint_schema.py
========================
Run with:  pytest test_endpoint_schema.py -v

Covers the four things most likely to bite the rest of the team if they're
wrong: path normalization, id generation, merge behaviour, and JSON
round-tripping (including against the formal JSON Schema).
"""

import json
import pytest
from jsonschema import validate as jsonschema_validate

from endpoint_schema import (
    Endpoint,
    EndpointRegistry,
    Evidence,
    HttpMethod,
    Parameter,
    Source,
    generate_id,
    merge_endpoints,
    normalize_path,
)


# ---------------------------------------------------------------------------
# normalize_path
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("raw,expected", [
    ("/api/v1/users/17", "/api/v1/users/{id}"),
    ("/api/v1/users/17/orders/9", "/api/v1/users/{id}/orders/{id}"),
    ("/api/v1/users/550e8400-e29b-41d4-a716-446655440000", "/api/v1/users/{id}"),
    ("/api/v1/users/507f1f77bcf86cd799439011", "/api/v1/users/{id}"),  # Mongo ObjectId
    ("/api/v1/users", "/api/v1/users"),          # no id segment -> unchanged
    ("/", "/"),                                   # root path
    ("api/v1/users/17/", "/api/v1/users/{id}"),  # missing/trailing slashes tolerated
])
def test_normalize_path(raw, expected):
    assert normalize_path(raw) == expected


def test_normalize_path_does_not_collapse_words_that_look_alphabetic():
    # "orders" and "users" are words, not ids -- must survive normalization
    assert normalize_path("/api/orders/users") == "/api/orders/users"


# ---------------------------------------------------------------------------
# generate_id
# ---------------------------------------------------------------------------

def test_generate_id_is_deterministic():
    id1 = generate_id(HttpMethod.GET, "/api/v1/users/{id}")
    id2 = generate_id(HttpMethod.GET, "/api/v1/users/{id}")
    assert id1 == id2


def test_generate_id_differs_by_method():
    get_id = generate_id(HttpMethod.GET, "/api/v1/users/{id}")
    post_id = generate_id(HttpMethod.POST, "/api/v1/users/{id}")
    assert get_id != post_id


def test_generate_id_differs_by_path():
    users_id = generate_id(HttpMethod.GET, "/api/v1/users/{id}")
    orders_id = generate_id(HttpMethod.GET, "/api/v1/orders/{id}")
    assert users_id != orders_id


# ---------------------------------------------------------------------------
# Endpoint construction
# ---------------------------------------------------------------------------

def test_endpoint_auto_populates_normalized_path_and_id():
    ep = Endpoint(method=HttpMethod.GET, path="/api/v1/users/17")
    assert ep.normalized_path == "/api/v1/users/{id}"
    assert ep.endpoint_id == generate_id(HttpMethod.GET, "/api/v1/users/{id}")


def test_endpoint_accepts_method_as_plain_string():
    # Stage 1/2 scripts may pass raw strings instead of the enum -- must not crash
    ep = Endpoint(method="POST", path="/api/v1/login")
    assert ep.method == HttpMethod.POST


# ---------------------------------------------------------------------------
# Serialization round-trip
# ---------------------------------------------------------------------------

def test_to_dict_from_dict_round_trip():
    ep = Endpoint(
        method=HttpMethod.GET,
        path="/api/v1/users/17",
        sources=[Source.CRAWLER],
        parameters=[Parameter(name="include", location="query", example="profile")],
        evidence=[Evidence(origin="main.js", detail="line 12")],
        status_codes_observed={"200": 2},
    )
    restored = Endpoint.from_dict(ep.to_dict())
    assert restored.to_dict() == ep.to_dict()


def test_to_json_from_json_round_trip():
    ep = Endpoint(method=HttpMethod.DELETE, path="/api/v1/orders/9", tags=["admin"])
    restored = Endpoint.from_json(ep.to_json())
    assert restored.endpoint_id == ep.endpoint_id
    assert restored.tags == ["admin"]


def test_serialized_output_validates_against_json_schema():
    with open("endpoint_schema.json") as f:
        schema = json.load(f)

    ep = Endpoint(
        method=HttpMethod.GET,
        path="/api/v1/users/17",
        sources=[Source.CRAWLER, Source.JS_STATIC],
        parameters=[Parameter(name="id", location="path", inferred_type="number")],
        evidence=[Evidence(origin="crawl", detail="link found")],
    )
    jsonschema_validate(ep.to_dict(), schema)  # raises if invalid


# ---------------------------------------------------------------------------
# merge_endpoints
# ---------------------------------------------------------------------------

def test_merge_unions_sources_and_sums_status_codes():
    a = Endpoint(
        method=HttpMethod.GET, path="/api/v1/users/17",
        sources=[Source.CRAWLER], status_codes_observed={"200": 1},
    )
    b = Endpoint(
        method=HttpMethod.GET, path="/api/v1/users/42",  # same shape
        sources=[Source.JS_STATIC], status_codes_observed={"200": 2, "404": 1},
    )
    merged = merge_endpoints(a, b)
    assert set(merged.sources) == {Source.CRAWLER, Source.JS_STATIC}
    assert merged.status_codes_observed == {"200": 3, "404": 1}


def test_merge_documented_is_true_if_either_side_is():
    a = Endpoint(method=HttpMethod.GET, path="/api/v1/users/1", documented=True)
    b = Endpoint(method=HttpMethod.GET, path="/api/v1/users/2", documented=False)
    assert merge_endpoints(a, b).documented is True


def test_merge_rejects_different_endpoints():
    a = Endpoint(method=HttpMethod.GET, path="/api/v1/users/1")
    b = Endpoint(method=HttpMethod.POST, path="/api/v1/users/1")  # different method
    with pytest.raises(ValueError):
        merge_endpoints(a, b)


# ---------------------------------------------------------------------------
# EndpointRegistry
# ---------------------------------------------------------------------------

def test_registry_deduplicates_on_add():
    reg = EndpointRegistry()
    reg.add(Endpoint(method=HttpMethod.GET, path="/api/v1/users/17", sources=[Source.CRAWLER]))
    reg.add(Endpoint(method=HttpMethod.GET, path="/api/v1/users/99", sources=[Source.JS_STATIC]))
    assert len(reg) == 1  # same method + normalized shape


def test_registry_save_and_load_json_round_trip(tmp_path):
    reg = EndpointRegistry()
    reg.add(Endpoint(method=HttpMethod.GET, path="/api/v1/users/17"))
    reg.add(Endpoint(method=HttpMethod.POST, path="/api/v1/login"))

    out_file = tmp_path / "endpoints.json"
    reg.save_json(str(out_file))

    reloaded = EndpointRegistry.load_json(str(out_file))
    assert len(reloaded) == 2
    assert {ep.endpoint_id for ep in reloaded.all()} == {ep.endpoint_id for ep in reg.all()}
